package com.example.proyectoprogra5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Productos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);
    }

    public void volverClickProductos(View view) {finish(); }

    public void CrearProductosClic(View view){
        Intent i = new Intent( this, CrearProductos.class);
        startActivity(i);
    }

    public void ListadoProductoClic(View view){
        Intent i = new Intent(this, Listado.class);
        startActivity(i);
    }
}