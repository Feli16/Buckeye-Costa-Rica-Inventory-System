package com.example.proyectoprogra5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Clic para entrar en las opciones de clientes
    public void ClientesClic(View view){
        Intent i = new Intent(this, Clientes.class);
        startActivity(i);
    }

    //Clic para entrar en las opciones de Pedidos
    public void PedidosClic(View view){
        Intent i = new Intent(this, Pedidos.class);
        startActivity(i);
    }

    //Clic para entrar en las opciones de Productos
    public void ProductosClic(View view){
        Intent i = new Intent(this, Productos.class);
        startActivity(i);
    }

    //Clic para entrar en las opciones de usuarios
    public void UsuarioClic(View view){
        Intent i = new Intent(this, Usuarios.class);
        startActivity(i);
    }


}