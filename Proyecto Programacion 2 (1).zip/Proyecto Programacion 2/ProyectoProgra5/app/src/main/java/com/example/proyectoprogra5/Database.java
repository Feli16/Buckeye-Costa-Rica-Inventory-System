package com.example.proyectoprogra5;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper {


    public static final String TABLA_CLIENTES = "TABLA_CLIENTES";
    public static final String COLUMNA_NOMBRE_CLIENTE = "NOMBRE_CLIENTE";
    public static final String COLUMNA_TELEFONO = "TELEFONO";
    public static final String COLUMNA_CORREO = "CORREO";

    public Database(@Nullable Context context) {
        super(context, "buckeyeDB", null, 1);
    }

    //se va a llamar la primera vez que llamemos a la base (se crea db y tablas)
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = " CREATE TABLE " + TABLA_CLIENTES + " (" + COLUMNA_NOMBRE_CLIENTE + " STRING PRIMARY KEY, " + COLUMNA_TELEFONO + " INTERGER, " + COLUMNA_CORREO + " TEXT )";

        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public boolean agregarUno(Clientes clientes) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMNA_NOMBRE_CLIENTE, clientes.getNombre());
        cv.put(COLUMNA_TELEFONO, clientes.getTelefono());
        cv.put(COLUMNA_CORREO, clientes.getCorreo());

        long insert = db.insert(TABLA_CLIENTES, null, cv);

        if (insert == -1) {
            return false;
        } else {
            return true;
        }


    }
}
