package com.example.proyectoprogra5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class CrearClientes extends AppCompatActivity {

    //Referencias
    Button btnGuardar,btnVolver,btnBorrar;
    ListView listadoClientes;
    EditText textNombre, textCorreo, textTelefono;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_clientes);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnVolver = findViewById(R.id.btnVolver);
        btnBorrar = findViewById(R.id.btnBorrar);
        listadoClientes = findViewById(R.id.listadoClientes);


        //Listeners
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Clientes clientes;

                try {
                    clientes = new Clientes(textNombre.getText().toString(), Integer.parseInt(textTelefono.toString()), textCorreo.getText().toString());

                    Toast.makeText(CrearClientes.this, "Actualizado con exito", Toast.LENGTH_SHORT).show();

                }catch(Exception e){
                    Toast.makeText(CrearClientes.this, "Error creando cliente", Toast.LENGTH_SHORT).show();

                    clientes = new Clientes("error",0,"error");

                }

                Database dataBase = new Database(CrearClientes.this);

                boolean Logro = dataBase.agregarUno(clientes);

                Toast.makeText(CrearClientes.this, "Se logro ingresar", Toast.LENGTH_SHORT).show();
            }
        });



    }

    public void volverClicClientesCrear(View view){
        finish();
    }
}