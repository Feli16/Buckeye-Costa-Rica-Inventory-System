package com.example.proyectoprogra5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Usuarios extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuarios);
    }

    public void CrearUsuariosClic(View view){
        Intent i = new Intent(this, CrearUsuarios.class);
        startActivity(i);
    }

    public void UsuriosListadoClic(View view){
        Intent i = new Intent(this, Listado.class);
        startActivity(i);
    }


    public void volverClicUsuarios(View view) {finish(); }
}